<?php

namespace App\Enums;

enum Scope: string
{
    case PRODUCT = 'product';
    case VARIANT = 'variant';
}
