<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id',
    'name',
    'label' => null,
    'value' => null,
    'required' => false,
    'error' => null,
    'variant' => 'default',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id',
    'name',
    'label' => null,
    'value' => null,
    'required' => false,
    'error' => null,
    'variant' => 'default',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $groupClass = $variant === 'default' ? 'form-group' : 'form-floating';

    $inputClass = 'form-control';
    $inputClass .= $error ? ' is-invalid' : '';
?>

<div class="<?php echo e($groupClass); ?>">
    <?php if($variant === 'default' && $label): ?>
        <label for="<?php echo e($id); ?>">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-danger">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <textarea id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" <?php if($required): echo 'required'; endif; ?> <?php echo $attributes->merge(['class' => $inputClass . ' ck-editor']); ?>><?php echo e($value); ?></textarea>

    <?php if($variant === 'floating' && $label): ?>
        <label for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="invalid-feedback"><?php echo e($error); ?></div>
    <?php endif; ?>
</div>

<?php if (! $__env->hasRenderedOnce('c221711e-96c6-400d-9eff-dd303d818a79')): $__env->markAsRenderedOnce('c221711e-96c6-400d-9eff-dd303d818a79');
$__env->startPush('scripts:before'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/40.1.0/classic/ckeditor.js"></script>
    <script>
        const CKInit = (element) => {
            if (!element || element.classList.contains('ck-loaded')) return;

            ClassicEditor.create(element, {
                toolbar: {
                    items: [
                        'heading', '|',
                        'bold', 'italic', 'underline', 'strikethrough', '|',
                        'numberedList', 'bulletedList', '|',
                        'link', 'blockQuote', 'insertTable', '|',
                        'undo', 'redo'
                    ]
                }
            }).then(editor => {
                element.classList.add('ck-loaded');

                editor.plugins.get('FileRepository').createUploadAdapter = loader => ({
                    upload: () =>
                        loader.file.then(file =>
                            new Promise((resolve, reject) => {
                                const reader = new FileReader();
                                reader.onload = () => resolve({
                                    default: reader.result
                                });
                                reader.onerror = reject;
                                reader.readAsDataURL(file);
                            })
                        )
                });
            }).catch(console.error);
        }
    </script>
<?php $__env->stopPush(); endif; ?>
<?php $__env->startPush('scripts:after'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const el = document.getElementById(<?php echo json_encode($id, 15, 512) ?>);
            CKInit(el);

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/components/forms/editor.blade.php ENDPATH**/ ?>