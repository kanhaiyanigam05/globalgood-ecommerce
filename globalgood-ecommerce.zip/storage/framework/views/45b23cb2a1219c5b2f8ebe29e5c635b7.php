<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'text',
    'id' => null,
    'class' => null,
    'label' => null,
    'varient' => 'default',
    'error' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'text',
    'id' => null,
    'class' => null,
    'label' => null,
    'varient' => 'default',
    'error' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $groupClass = $varient === 'default' ? 'form-group' : 'form-floating';
    if ($type === 'password') {
        $groupClass .= ' position-relative';
    }

    $inputClass = $varient === 'default' ? 'form-control' : 'form-control floating';
    $inputClass .= $error ? ' is-invalid' : '';
?>

<div class="<?php echo e($groupClass); ?>">
    <?php if($varient === 'default'): ?>
        <label for="<?php echo e($id); ?>">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-danger">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <input type="<?php echo e($type); ?>" id="<?php echo e($id); ?>" <?php if($required): echo 'required'; endif; ?> <?php echo $attributes->merge(['class' => $inputClass]); ?> />

    <?php if($varient === 'floating'): ?>
        <label for="<?php echo e($id); ?>" style="left: 0; top: 0; height: 100%; pointer-events: none;">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-danger">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <?php if($type === 'password'): ?>
        <span class="password-toggle" data-target="<?php echo e($id); ?>"
            style="
                position: absolute;
                top: 50%;
                right: 12px;
                transform: translateY(-50%);
                cursor: pointer;
                z-index: 10;
            ">
            <i class="fa fa-eye"></i>
        </span>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="invalid-feedback mb-1"><?php echo e($error); ?></div>
    <?php endif; ?>
</div>

<?php if (! $__env->hasRenderedOnce('eb63d130-6676-40a0-a1c1-37bec2f9c6b7')): $__env->markAsRenderedOnce('eb63d130-6676-40a0-a1c1-37bec2f9c6b7');
$__env->startPush('scripts:after'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const passwordToggle = document.querySelectorAll('.password-toggle');
            passwordToggle.forEach((toggle) => {
                toggle.addEventListener('click', function() {
                    const target = document.getElementById(this.dataset.target);
                    if (target.type === 'password') {
                        target.type = 'text';
                        this.querySelector('i').classList.remove('fa-eye');
                        this.querySelector('i').classList.add('fa-eye-slash');
                    } else {
                        target.type = 'password';
                        this.querySelector('i').classList.remove('fa-eye-slash');
                        this.querySelector('i').classList.add('fa-eye');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/components/forms/input.blade.php ENDPATH**/ ?>