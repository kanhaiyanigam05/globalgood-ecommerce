<div class="table-responsive">
    <table class="table table-hover align-middle mb-0" id="taxRegionsTable">
        <thead class="bg-light">
            <tr class="f-s-12 text-uppercase text-muted">
                <th class="ps-4 py-3">Region</th>
                <th class="py-3">Status</th>
                <th class="py-3 text-end pe-4">Manage</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $tax = $country->taxSettings->first(); ?>
            <tr class="region-row" onclick="window.location.href='<?php echo e(route('admin.settings.tax.edit', $country->id)); ?>'" style="cursor: pointer;">
                <td class="ps-4">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(asset('flags/'.$country->flag)); ?>" class="country-flag me-3">
                        <span class="f-w-600"><?php echo e($country->name); ?></span>
                    </div>
                </td>
                <td>
                    <?php if($tax && $tax->is_active): ?>
                        <span class="badge bg-light-success text-success border-success f-s-11">
                            <i class="ph ph-check-circle me-1"></i> Collecting
                        </span>
                    <?php else: ?>
                        <span class="badge bg-light text-muted border f-s-11">Not collecting</span>
                    <?php endif; ?>
                </td>
                <td class="text-end pe-4">
                    <i class="ph ph-caret-right text-muted"></i>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="p-3 border-top d-flex align-items-center justify-content-between">
    <div class="f-s-13 text-muted">
        Showing <?php echo e($countries->firstItem()); ?> to <?php echo e($countries->lastItem()); ?> of <?php echo e($countries->total()); ?> regions
    </div>
    <div class="custom-pagination">
        <?php if($countries->onFirstPage()): ?>
            <span class="custom-pg-btn disabled"><i class="ph ph-caret-left"></i></span>
        <?php else: ?>
            <a href="<?php echo e($countries->previousPageUrl()); ?>" class="custom-pg-btn"><i class="ph ph-caret-left"></i></a>
        <?php endif; ?>

        <?php if($countries->hasMorePages()): ?>
            <a href="<?php echo e($countries->nextPageUrl()); ?>" class="custom-pg-btn"><i class="ph ph-caret-right"></i></a>
        <?php else: ?>
            <span class="custom-pg-btn disabled"><i class="ph ph-caret-right"></i></span>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/admin/settings/tax/table.blade.php ENDPATH**/ ?>