<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'method' => 'POST',
    'action' => null,
    'id' => null,
    'processingText' => 'Processing...',
    'varient' => 'default',
    'class' => '',
    'confirm' => false,
    'confirmTitle' => 'Confirm Action',
    'confirmMessage' => 'Are you sure you want to continue?',
    'confirmButtonText' => 'Yes, Continue',
    'confirmVariant' => 'danger',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'method' => 'POST',
    'action' => null,
    'id' => null,
    'processingText' => 'Processing...',
    'varient' => 'default',
    'class' => '',
    'confirm' => false,
    'confirmTitle' => 'Confirm Action',
    'confirmMessage' => 'Are you sure you want to continue?',
    'confirmButtonText' => 'Yes, Continue',
    'confirmVariant' => 'danger',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $httpMethod = strtoupper($method);
    $formMethod = in_array($httpMethod, ['GET', 'POST']) ? $httpMethod : 'POST';

    $formClass = $class;
    $formClass .= $varient === 'reactive' ? ' reactive' : '';

    $variants = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark'];

    $confirmVariant = in_array($confirmVariant, $variants) ? $confirmVariant : 'danger';
?>

<form method="<?php echo e(strtolower($formMethod)); ?>" action="<?php echo e($action); ?>" id="<?php echo e($id); ?>"
    data-processing-text="<?php echo e($processingText); ?>" data-confirm="<?php echo e($confirm ? 'true' : 'false'); ?>"
    <?php echo e($attributes->merge(['class' => $formClass])); ?>>
    <?php echo csrf_field(); ?>

    <?php if(!in_array($httpMethod, ['GET', 'POST'])): ?>
        <?php echo method_field($httpMethod); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>

</form>

<?php if($confirm): ?>
    <div class="modal fade" tabindex="-1" id="confirmModal-<?php echo e($id); ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header bg-<?php echo e($confirmVariant); ?>">
                    <h5 class="modal-title text-white">
                        <?php echo e($confirmTitle); ?>

                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <p class="text-dark mb-0"><?php echo e($confirmMessage); ?></p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="btn btn-<?php echo e($confirmVariant); ?> confirm-submit">
                        <?php echo e($confirmButtonText); ?>

                    </button>
                </div>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (! $__env->hasRenderedOnce('285f4e93-10f7-4d12-b114-792bb00946a5')): $__env->markAsRenderedOnce('285f4e93-10f7-4d12-b114-792bb00946a5');
$__env->startPush('scripts:after'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            document.querySelectorAll('form.reactive').forEach(function(form) {

                let confirmed = false;

                form.addEventListener('submit', function(e) {

                    if (form.dataset.confirm === 'true' && !confirmed) {
                        e.preventDefault();

                        const modalEl = document.getElementById('confirmModal-' + form.id);
                        const modal = new bootstrap.Modal(modalEl);
                        modal.show();

                        modalEl.querySelector('.confirm-submit').onclick = function() {
                            confirmed = true;
                            modal.hide();
                            form.requestSubmit();
                        };

                        return;
                    }

                    const buttons = form.querySelectorAll(
                        'button[type="submit"], input[type="submit"]'
                    );

                    buttons.forEach(function(btn) {
                        btn.disabled = true;

                        if (btn.tagName === 'BUTTON') {
                            btn.innerHTML =
                                `<span class="spinner-border spinner-border-sm me-1"></span>${form.dataset.processingText}`;
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/components/forms/form.blade.php ENDPATH**/ ?>