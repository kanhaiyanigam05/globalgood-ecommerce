<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-11">
                <!-- Breadcrumb start -->
                <div class="row m-1">
                    <div class="col-12">
                        <h4 class="main-title">Collections</h4>
                        <ul class="app-line-breadcrumbs mb-3">
                            <li>
                                <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.dashboard')); ?>">
                                    <span><i class="ph-duotone ph-house f-s-16"></i> Home</span>
                                </a>
                            </li>
                            <li>
                                <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.collections.index')); ?>">
                                    <span><i class="ph-duotone ph-folder f-s-16"></i> Collections</span>
                                </a>
                            </li>
                            <li class="active">
                                <a class="f-s-14 f-w-500" href="#">Create Collection</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['action' => route('admin.collections.store'),'method' => 'post','enctype' => 'multipart/form-data','varient' => 'reactive','class' => 'row']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.collections.store')),'method' => 'post','enctype' => 'multipart/form-data','varient' => 'reactive','class' => 'row']); ?>
                    <div class="col-lg-8">
                        <!-- Main Details -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-body">
                                <div class="mb-4">
                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'title','name' => 'title','label' => 'Title','placeholder' => 'e.g. Summer collection, Under $100, Staff picks','value' => old('title'),'error' => $errors->first('title'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'title','name' => 'title','label' => 'Title','placeholder' => 'e.g. Summer collection, Under $100, Staff picks','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('title')),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('title')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                </div>
                                <div class="mb-2">
                                    <?php if (isset($component)) { $__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.editor','data' => ['id' => 'description','name' => 'description','label' => 'Description','value' => old('description'),'error' => $errors->first('description'),'placeholder' => 'Enter collection description...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'description','name' => 'description','label' => 'Description','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('description')),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('description')),'placeholder' => 'Enter collection description...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f)): ?>
<?php $attributes = $__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f; ?>
<?php unset($__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f)): ?>
<?php $component = $__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f; ?>
<?php unset($__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Collection Type Selection -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h6 class="mb-0">Collection type</h6>
                            </div>
                            <div class="card-body">
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="type" id="type_manual" value="manual" <?php echo e(old('type', 'manual') === 'manual' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="type_manual">
                                        <strong>Manual</strong>
                                        <p class="text-muted small mb-0">Add products to this collection one by one.</p>
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="type" id="type_smart" value="smart" <?php echo e(old('type') === 'smart' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="type_smart">
                                        <strong>Smart</strong>
                                        <p class="text-muted small mb-0">Existing and future products that match the conditions you set will automatically be added to this collection.</p>
                                    </label>
                                </div>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Smart Collection - Conditions (Initially Hidden) -->
                        <div id="smart-conditions-wrapper" class="card shadow-sm mb-4 <?php echo e(old('type') === 'smart' ? '' : 'd-none'); ?>">
                            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">Conditions</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <p class="mb-2 fw-medium">Products must match:</p>
                                    <div class="d-flex gap-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="condition_type" id="cond_all" value="all" <?php echo e(old('condition_type', 'all') === 'all' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cond_all">all conditions</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="condition_type" id="cond_any" value="any" <?php echo e(old('condition_type') === 'any' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cond_any">any condition</label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['condition_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div id="conditions-list">
                                    <?php if(old('conditions')): ?>
                                        <?php $__currentLoopData = old('conditions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="condition-row row gx-2 mb-2">
                                                <div class="col-4">
                                                    <select name="conditions[<?php echo e($index); ?>][field]" class="form-select condition-field">
                                                        <?php $__currentLoopData = ['title'=>'Product title','type'=>'Product type','category'=>'Category','price'=>'Product price','compare_at_price'=>'Compare at price','inventory_stock'=>'Inventory stock','tag'=>'Product tag']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($val); ?>" <?php echo e($condition['field'] === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-3">
                                                    <select name="conditions[<?php echo e($index); ?>][operator]" class="form-select condition-operator" data-initial="<?php echo e($condition['operator']); ?>">
                                                        
                                                    </select>
                                                </div>
                                                <div class="col-4">
                                                    <input type="text" name="conditions[<?php echo e($index); ?>][value]" class="form-control condition-value" value="<?php echo e($condition['value']); ?>" placeholder="Value">
                                                    <?php $__errorArgs = ["conditions.{$index}.value"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger small"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-1">
                                                    <button type="button" class="btn btn-link text-danger remove-condition-btn p-0">
                                                        <i class="ph ph-trash f-s-18"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <?php $__errorArgs = ['conditions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <button type="button" class="btn btn-outline-secondary btn-sm mt-3" id="add-condition-btn">
                                    <i class="ph ph-plus"></i> Add another condition
                                </button>
                            </div>
                        </div>

                        <!-- Manual Collection - Products (Initially Visible) -->
                        <div id="manual-products-wrapper" class="card shadow-sm mb-4 <?php echo e(old('type', 'manual') === 'manual' ? '' : 'd-none'); ?>">
                            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">Products</h6>
                                <button type="button" class="btn btn-outline-secondary btn-sm" id="browse-products-btn">Browse</button>
                            </div>
                            <div class="card-body">
                                <?php $__errorArgs = ['product_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger py-2 px-3 small mb-3">
                                        <i class="ph ph-warning-circle"></i> <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0"><i class="ph ph-magnifying-glass"></i></span>
                                        <input type="text" id="product-search" class="form-control border-start-0" placeholder="Search products...">
                                    </div>
                                    <div id="search-results-dropdown" class="dropdown-menu w-100 shadow-sm" style="max-height: 250px; overflow-y: auto;"></div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-hover align-middle" id="selected-products-table">
                                        <thead>
                                            <tr>
                                                <th width="50"></th>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th width="50"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id="no-products-placeholder">
                                                <td colspan="4" class="text-center py-5">
                                                    <div class="text-muted">
                                                        <i class="ph ph-tag f-s-40 mb-3 d-block"></i>
                                                        There are no products in this collection.
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h6 class="mb-0">Publishing</h6>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span>Active Status</span>
                                    <?php if (isset($component)) { $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.switch','data' => ['name' => 'status','id' => 'status','checked' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','id' => 'status','checked' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $attributes = $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $component = $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
                                </div>
                                <hr class="my-3 opacity-10">
                                <p class="small text-muted mb-0">Collections status determines visibility on your storefront.</p>
                            </div>
                        </div>

                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h6 class="mb-0">Collection image</h6>
                            </div>
                            <div class="card-body text-center">
                                <?php if (isset($component)) { $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.file','data' => ['name' => 'image','label' => '','error' => $errors->first('image')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','label' => '','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('image'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $attributes = $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $component = $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
                                <p class="small text-muted mt-2">Upload an image to represent this collection.</p>
                            </div>
                        </div>

                        <div class="card shadow-sm border-primary">
                            <div class="card-body d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">Save Collection</button>
                            </div>
                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Templates -->
    <template id="condition-row-template">
        <div class="condition-row row gx-2 mb-2">
            <div class="col-4">
                <select name="conditions[INDEX][field]" class="form-select condition-field">
                    <option value="title">Product title</option>
                    <option value="type">Product type</option>
                    <option value="category">Category</option>
                    <option value="price">Product price</option>
                    <option value="compare_at_price">Compare at price</option>
                    <option value="inventory_stock">Inventory stock</option>
                    <option value="tag">Product tag</option>
                </select>
            </div>
            <div class="col-3">
                <select name="conditions[INDEX][operator]" class="form-select condition-operator">
                    <option value="equals">is equal to</option>
                    <option value="not_equals">is not equal to</option>
                    <option value="contains">contains</option>
                    <option value="not_contains">does not contain</option>
                    <option value="greater_than">is greater than</option>
                    <option value="less_than">is less than</option>
                    <option value="starts_with">starts with</option>
                    <option value="ends_with">ends with</option>
                </select>
            </div>
            <div class="col-4">
                <input type="text" name="conditions[INDEX][value]" class="form-control condition-value" placeholder="Value">
            </div>
            <div class="col-1">
                <button type="button" class="btn btn-link text-danger remove-condition-btn p-0">
                    <i class="ph ph-trash f-s-18"></i>
                </button>
            </div>
        </div>
    </template>

    <template id="selected-product-row">
        <tr>
            <td><div class="rounded bg-light" style="width: 40px; height: 40px; border: 1px solid #eee;"></div></td>
            <td>
                <div class="fw-medium">PRODUCT_TITLE</div>
                <input type="hidden" name="product_ids[]" value="PRODUCT_ID">
            </td>
            <td class="text-muted">$PRODUCT_PRICE</td>
            <td class="text-end">
                <button type="button" class="btn btn-link text-danger remove-product-btn p-0">
                    <i class="ph ph-x f-s-16"></i>
                </button>
            </td>
        </tr>
    </template>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts:after'); ?>
<script>
    $(document).ready(function() {
        // Toggle Manual/Smart sections
        $('input[name="type"]').change(function() {
            if (this.value === 'smart') {
                $('#smart-conditions-wrapper').removeClass('d-none');
                $('#manual-products-wrapper').addClass('d-none');
            } else {
                $('#smart-conditions-wrapper').addClass('d-none');
                $('#manual-products-wrapper').removeClass('d-none');
            }
        });

        // Condition Builder Logic
        let conditionIndex = <?php echo e(old('conditions') ? count(old('conditions')) : 0); ?>;
        const fieldOperators = {
            'title': ['equals', 'not_equals', 'contains', 'not_contains', 'starts_with', 'ends_with', 'is_empty', 'is_not_empty'],
            'type': ['equals', 'not_equals'],
            'category': ['equals', 'not_equals'],
            'price': ['equals', 'not_equals', 'greater_than', 'less_than'],
            'compare_at_price': ['equals', 'not_equals', 'greater_than', 'less_than'],
            'inventory_stock': ['equals', 'not_equals', 'greater_than', 'less_than'],
            'tag': ['equals', 'not_equals', 'contains', 'not_contains']
        };

        const operatorLabels = {
            'equals': 'is equal to',
            'not_equals': 'is not equal to',
            'contains': 'contains',
            'not_contains': 'does not contain',
            'greater_than': 'is greater than',
            'less_than': 'is less than',
            'starts_with': 'starts with',
            'ends_with': 'ends with',
            'is_empty': 'is empty',
            'is_not_empty': 'is not empty'
        };

        function updateOperators(row) {
            const field = row.find('.condition-field').val();
            const operatorSelect = row.find('.condition-operator');
            const currentValue = operatorSelect.val() || operatorSelect.data('initial');
            
            operatorSelect.empty();
            const available = fieldOperators[field] || fieldOperators['title'];
            
            available.forEach(op => {
                operatorSelect.append(`<option value="${op}" ${currentValue == op ? 'selected' : ''}>${operatorLabels[op]}</option>`);
            });

            // Toggle value input for empty/not empty
            const valueInput = row.find('.condition-value');
            if (['is_empty', 'is_not_empty'].includes(operatorSelect.val())) {
                valueInput.addClass('invisible');
            } else {
                valueInput.removeClass('invisible');
            }
        }

        function addCondition() {
            const template = $('#condition-row-template').html();
            const html = $(template.replace(/INDEX/g, conditionIndex++));
            $('#conditions-list').append(html);
            updateOperators(html);
        }

        // Initialize existing rows (from old input)
        $('.condition-row').each(function() {
            updateOperators($(this));
        });

        $('#add-condition-btn').click(addCondition);
        
        $(document).on('change', '.condition-field', function() {
            updateOperators($(this).closest('.condition-row'));
        });

        $(document).on('change', '.condition-operator', function() {
            const row = $(this).closest('.condition-row');
            const valueInput = row.find('.condition-value');
            if (['is_empty', 'is_not_empty'].includes($(this).val())) {
                valueInput.addClass('invisible');
            } else {
                valueInput.removeClass('invisible');
            }
        });

        $(document).on('click', '.remove-condition-btn', function() {
            $(this).closest('.condition-row').remove();
            if ($('.condition-row').length === 0) addCondition();
        });

        // Add initial condition if none exist
        if ($('.condition-row').length === 0) {
            addCondition();
        }

        // Product Search Logic for Manual Collection
        let searchTimeout;
        $('#product-search').on('input', function() {
            const query = $(this).val();
            clearTimeout(searchTimeout);
            
            if (query.length < 2) {
                $('#search-results-dropdown').removeClass('show').empty();
                return;
            }

            searchTimeout = setTimeout(() => {
                $.get("<?php echo e(route('admin.collections.search-products')); ?>", { q: query }, function(data) {
                    const dropdown = $('#search-results-dropdown');
                    dropdown.empty();
                    
                    if (data.length > 0) {
                        data.forEach(product => {
                            dropdown.append(`
                                <button type="button" class="dropdown-item d-flex justify-content-between align-items-center py-2 add-product-item" 
                                    data-id="${product.id}" data-title="${product.title}" data-price="${(product.price / 100).toFixed(2)}">
                                    <span>${product.title}</span>
                                    <span class="text-muted small">$${(product.price / 100).toFixed(2)}</span>
                                </button>
                            `);
                        });
                        dropdown.addClass('show');
                    } else {
                        dropdown.removeClass('show');
                    }
                });
            }, 300);
        });

        // Add product from search
        $(document).on('click', '.add-product-item', function() {
            const id = $(this).data('id');
            const title = $(this).data('title');
            const price = $(this).data('price');

            // Check if already added
            if ($(`input[name="product_ids[]"][value="${id}"]`).length > 0) {
                window.toast.warning('Product already added');
                return;
            }

            $('#no-products-placeholder').hide();
            
            const template = $('#selected-product-row').html();
            const html = template.replace(/PRODUCT_TITLE/g, title)
                                .replace(/PRODUCT_ID/g, id)
                                .replace(/PRODUCT_PRICE/g, price);
            
            $('#selected-products-table tbody').append(html);
            $('#product-search').val('');
            $('#search-results-dropdown').removeClass('show');
        });

        // Remove product
        $(document).on('click', '.remove-product-btn', function() {
            $(this).closest('tr').remove();
            if ($('#selected-products-table tbody tr').length === 1) { // Only placeholder row left conceptually
                 $('#no-products-placeholder').show();
            }
        });

        // Hide dropdown on clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#product-search, #search-results-dropdown').length) {
                $('#search-results-dropdown').removeClass('show');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/admin/collections/create.blade.php ENDPATH**/ ?>