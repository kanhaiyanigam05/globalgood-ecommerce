<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset($data->site_favicon)); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset($data->site_favicon)); ?>" type="image/x-icon">
    <title>Admin - <?php echo e($data->site_name); ?></title>
    <!-- Animation css -->
    <link rel="stylesheet" href="<?php echo e(asset('admins/vendor/animation/animate.min.css')); ?>">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/" rel="preconnect">
    <link crossorigin href="https://fonts.gstatic.com/" rel="preconnect">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
        rel="stylesheet">

    <!-- phosphor-icon css-->
    <link href="<?php echo e(asset('admins/vendor/phosphor/phosphor-bold.css')); ?>" rel="stylesheet">

    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/vendor/bootstrap/bootstrap.min.css')); ?>">

    <!-- Simplebar css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/vendor/simplebar/simplebar.css')); ?>">

    <!--font-awesome-css-->
    <link rel="stylesheet" href="<?php echo e(asset('admins/vendor/fontawesome/css/all.css')); ?>">

    <?php echo $__env->yieldPushContent('styles:before'); ?>
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/css/style.css')); ?>">

    <!-- Responsive css  -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/css/responsive.css')); ?>">
    <?php echo \Devrabiul\ToastMagic\Facades\ToastMagic::styles(); ?>

    <?php echo $__env->yieldPushContent('styles:after'); ?>
</head>

<body>
    <div class="app-wrapper">
        <div class="loader-wrapper">
            <div class="app-loader">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="app-content">
            <!-- Header Section starts -->
            <header class="header-main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-8 col-sm-6 d-flex align-items-center header-left p-0">
                            <span class="header-toggle ">
                                <i class="ph ph-squares-four"></i>
                            </span>

                            <div class="header-searchbar w-100">
                                <form action="#" class="mx-sm-3 app-form app-icon-form ">
                                    <div class="position-relative">
                                        <input aria-label="Search" class="form-control" placeholder="Search..."
                                            type="search">
                                        <i class="ti ti-search text-dark"></i>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="col-4 col-sm-6 d-flex align-items-center justify-content-end header-right p-0">

                            <ul class="d-flex align-items-center">

                                <li class="header-dark">
                                    <div class="sun-logo head-icon bg-light-dark rounded-circle f-s-22 p-2">
                                        <i class="ph ph-moon-stars"></i>
                                    </div>
                                    <div class="moon-logo head-icon bg-light-dark rounded-circle f-s-22 p-2">
                                        <i class="ph ph-sun-dim"></i>
                                    </div>
                                </li>

                                <li class="header-notification">
                                    <a aria-controls="notificationcanvasRight"
                                        class="d-block head-icon position-relative bg-light-dark rounded-circle f-s-22 p-2"
                                        data-bs-target="#notificationcanvasRight" data-bs-toggle="offcanvas"
                                        href="#" role="button">
                                        <i class="ph ph-bell"></i>
                                        <span
                                            class="position-absolute translate-middle p-1 bg-primary border border-light rounded-circle animate__animated animate__fadeIn animate__infinite animate__slower"></span>
                                    </a>
                                    <div aria-labelledby="notificationcanvasRightLabel"
                                        class="offcanvas offcanvas-end header-notification-canvas"
                                        id="notificationcanvasRight" tabindex="-1">
                                        <div class="offcanvas-header">
                                            <h5 class="offcanvas-title" id="notificationcanvasRightLabel">
                                                Notification</h5>
                                            <button aria-label="Close" class="btn-close" data-bs-dismiss="offcanvas"
                                                type="button"></button>
                                        </div>
                                        <div class="offcanvas-body app-scroll p-0">
                                            <div class="head-container">
                                                

                                                <div class="hidden-massage py-4 px-3">
                                                    <div>
                                                        <i class="ph-duotone  ph-bell-ringing f-s-50 text-primary"></i>
                                                    </div>
                                                    <div>
                                                        <h6 class="mb-0">Notification Not Found</h6>
                                                        <p class="text-dark">When you have any notifications added
                                                            here,will
                                                            appear here.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
            <!-- Header Section ends -->

            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

      

        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-9 col-12">
                        <p class="footer-text f-w-600 mb-0">Copyright © <?php echo e(date('Y') . ' ' . $data->site_name); ?>. All
                            rights reserved
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    </div>


    <!-- latest jquery-->
    <script src="<?php echo e(asset('admins/js/jquery-3.6.3.min.js')); ?>"></script>

    <!-- Bootstrap js-->
    <script src="<?php echo e(asset('admins/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Simple bar js-->
    <script src="<?php echo e(asset('admins/vendor/simplebar/simplebar.js')); ?>"></script>

    <!-- phosphor icon -->
    <script src="<?php echo e(asset('admins/vendor/phosphor/phosphor.js')); ?>"></script>

    <!-- Customizer js-->
    <script src="<?php echo e(asset('admins/js/customizer.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts:before'); ?>
    <!-- App js-->
    <script src="<?php echo e(asset('admins/js/script.js')); ?>"></script>
    <?php echo \Devrabiul\ToastMagic\Facades\ToastMagic::scripts(); ?>

    <script>
        window.toast = new ToastMagic();
        <?php if(session('success')): ?>
            window.toast.success('<?php echo e(session('success')); ?>');
        <?php endif; ?>
        <?php if(session('error')): ?>
            window.toast.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
        <?php if(session('warning')): ?>
            window.toast.warning('<?php echo e(session('warning')); ?>');
        <?php endif; ?>
        <?php if(session('info')): ?>
            window.toast.info('<?php echo e(session('info')); ?>');
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldPushContent('scripts:after'); ?>
</body>

</html>
<?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>