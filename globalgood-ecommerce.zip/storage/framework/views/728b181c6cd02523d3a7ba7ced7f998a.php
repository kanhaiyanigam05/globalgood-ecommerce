
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Breadcrumb start -->
                <div class="row m-1">
                    <div class="col-12">
                        <h4 class="main-title">Products</h4>
                        <ul class="app-line-breadcrumbs mb-3">
                            <li>
                                <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.dashboard')); ?>">
                                    <span><i class="ph-duotone ph-house f-s-16"></i> Home</span>
                                </a>
                            </li>
                            <li>
                                <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.products.index')); ?>">
                                    <span><i class="ph-duotone ph-package f-s-16"></i> Products</span>
                                </a>
                            </li>
                            <li class="active">
                                <a class="f-s-14 f-w-500" href="#">Edit Product</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Breadcrumb end -->

                <!-- Main Product Form -->
                <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['action' => route('admin.products.update', Crypt::encryptString($product->id)),'method' => 'put','enctype' => 'multipart/form-data','varient' => 'reactive','class' => 'row']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.update', Crypt::encryptString($product->id))),'method' => 'put','enctype' => 'multipart/form-data','varient' => 'reactive','class' => 'row']); ?>
                    <div class="col-lg-7 col-md-8">
                        <!-- Product Details Card -->
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="ph-duotone ph-info"></i> Product Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="app-form">
                                    <div class="row">
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'title','name' => 'title','label' => 'Product Title','placeholder' => 'Enter Product Title','value' => old('title', $product->title),'error' => $errors->first('title'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'title','name' => 'title','label' => 'Product Title','placeholder' => 'Enter Product Title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('title', $product->title)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('title')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'slug','name' => 'slug','label' => 'URL Slug','placeholder' => 'auto-generated-from-title','value' => old('slug', $product->slug),'error' => $errors->first('slug')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'slug','name' => 'slug','label' => 'URL Slug','placeholder' => 'auto-generated-from-title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('slug', $product->slug)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('slug'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                            <small class="text-muted">Leave blank to auto-generate from title</small>
                                        </div>

                                        
                                        <div class="col-md-6 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal9c09515a9656f77374b5e3722ba2b060 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c09515a9656f77374b5e3722ba2b060 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.hierarchical-select','data' => ['id' => 'category_id','name' => 'category_id','label' => 'Category','clearable' => true,'placeholder' => 'Select a category','searchPlaceholder' => 'Search categories...','options' => $categories,'apiUrl' => ''.e(route('admin.categories.hierarchical_data')).'','value' => old('category_id', $product->category_id),'error' => $errors->first('category_id'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.hierarchical-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'category_id','name' => 'category_id','label' => 'Category','clearable' => true,'placeholder' => 'Select a category','searchPlaceholder' => 'Search categories...','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'apiUrl' => ''.e(route('admin.categories.hierarchical_data')).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('category_id', $product->category_id)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('category_id')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c09515a9656f77374b5e3722ba2b060)): ?>
<?php $attributes = $__attributesOriginal9c09515a9656f77374b5e3722ba2b060; ?>
<?php unset($__attributesOriginal9c09515a9656f77374b5e3722ba2b060); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c09515a9656f77374b5e3722ba2b060)): ?>
<?php $component = $__componentOriginal9c09515a9656f77374b5e3722ba2b060; ?>
<?php unset($__componentOriginal9c09515a9656f77374b5e3722ba2b060); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'number','step' => '0.01','name' => 'price','label' => 'Price ($)','placeholder' => '0.00','value' => old('price', $product->price_formatted),'error' => $errors->first('price'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','step' => '0.01','name' => 'price','label' => 'Price ($)','placeholder' => '0.00','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('price', $product->price_formatted)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('price')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'number','step' => '0.01','name' => 'compare_at_price','label' => 'Compare At Price ($)','placeholder' => '0.00','value' => old('compare_at_price', $product->compare_at_price_formatted),'error' => $errors->first('compare_at_price')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','step' => '0.01','name' => 'compare_at_price','label' => 'Compare At Price ($)','placeholder' => '0.00','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('compare_at_price', $product->compare_at_price_formatted)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('compare_at_price'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                            <small class="text-muted">Original price before discount</small>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'number','name' => 'quantity','label' => 'Stock Quantity','placeholder' => '0','value' => old('quantity', $product->quantity),'error' => $errors->first('quantity'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'quantity','label' => 'Stock Quantity','placeholder' => '0','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('quantity', $product->quantity)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('quantity')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.file','data' => ['name' => 'images','label' => 'Product Images','placeholder' => 'Upload Product Images','value' => $images,'error' => $errors->first('images'),'multiple' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'images','label' => 'Product Images','placeholder' => 'Upload Product Images','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($images),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('images')),'multiple' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $attributes = $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $component = $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
                                            <small class="text-muted">Upload multiple images (JPEG, PNG, GIF, WebP - Max 2MB
                                                each)</small>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginalea7b7095850fe8bc9657025b89ccf5a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.textarea','data' => ['id' => 'short_description','rows' => '3','name' => 'short_description','label' => 'Short Description','placeholder' => 'Brief product summary (shown in listings)','value' => old('short_description', $product->short_description),'error' => $errors->first('short_description')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'short_description','rows' => '3','name' => 'short_description','label' => 'Short Description','placeholder' => 'Brief product summary (shown in listings)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('short_description', $product->short_description)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('short_description'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5)): ?>
<?php $attributes = $__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5; ?>
<?php unset($__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea7b7095850fe8bc9657025b89ccf5a5)): ?>
<?php $component = $__componentOriginalea7b7095850fe8bc9657025b89ccf5a5; ?>
<?php unset($__componentOriginalea7b7095850fe8bc9657025b89ccf5a5); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.editor','data' => ['id' => 'description','rows' => '8','name' => 'description','label' => 'Full Description','placeholder' => 'Detailed product description','value' => old('description', $product->description),'error' => $errors->first('description')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'description','rows' => '8','name' => 'description','label' => 'Full Description','placeholder' => 'Detailed product description','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('description', $product->description)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('description'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f)): ?>
<?php $attributes = $__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f; ?>
<?php unset($__attributesOriginaleaf1bda6ac9fadd697ee278a8c18cd4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f)): ?>
<?php $component = $__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f; ?>
<?php unset($__componentOriginaleaf1bda6ac9fadd697ee278a8c18cd4f); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Shopify-Style Variant Options Component -->
                        <?php if (isset($component)) { $__componentOriginal6400dc7a1ca0d19b1680d74801a61426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6400dc7a1ca0d19b1680d74801a61426 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.variant-select','data' => ['initialOptions' => $initialOptions,'initialVariants' => $initialVariants]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('variant-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['initialOptions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($initialOptions),'initialVariants' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($initialVariants)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6400dc7a1ca0d19b1680d74801a61426)): ?>
<?php $attributes = $__attributesOriginal6400dc7a1ca0d19b1680d74801a61426; ?>
<?php unset($__attributesOriginal6400dc7a1ca0d19b1680d74801a61426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6400dc7a1ca0d19b1680d74801a61426)): ?>
<?php $component = $__componentOriginal6400dc7a1ca0d19b1680d74801a61426; ?>
<?php unset($__componentOriginal6400dc7a1ca0d19b1680d74801a61426); ?>
<?php endif; ?>

                    </div>

                    <div class="col-lg-4 col-md-5">
                        <!-- Options Card -->
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="ph-duotone ph-toggles"></i> Options</h5>
                            </div>
                            <div class="card-body">
                                <?php if (isset($component)) { $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.switch','data' => ['id' => 'status','name' => 'status','label' => 'Published','checked' => old('status', $product->status)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'status','name' => 'status','label' => 'Published','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('status', $product->status))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $attributes = $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $component = $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
                                <small class="text-muted d-block mb-3">Make product visible on storefront</small>

                                <?php if (isset($component)) { $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.switch','data' => ['id' => 'is_featured','name' => 'is_featured','label' => 'Featured Product','checked' => old('is_featured', $product->is_featured)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'is_featured','name' => 'is_featured','label' => 'Featured Product','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('is_featured', $product->is_featured))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $attributes = $__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__attributesOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800)): ?>
<?php $component = $__componentOriginal8e00a21e98caa7fd043fcc9e6267f800; ?>
<?php unset($__componentOriginal8e00a21e98caa7fd043fcc9e6267f800); ?>
<?php endif; ?>
                                <small class="text-muted d-block">Show in featured sections</small>
                            </div>
                        </div>

                        <!-- Product Attributes Card -->
                        <div class="card mt-3" id="product-attributes-wrapper" style="<?php echo e(count($productAttributes) > 0 ? '' : 'display:none;'); ?>">
                            <div class="card-header">
                                <h5><i class="ph-duotone ph-list-bullets"></i> Product Attributes</h5>
                            </div>
                            <div class="card-body">
                                <div class="app-form" id="product-attributes-container">
                                    <?php
                                        $selectedProductAttrs = $product->attributes->pluck('pivot.value', 'id')->toArray();
                                    ?>
                                    <?php $__currentLoopData = $productAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3 attribute-item" data-id="<?php echo e($attr->id); ?>">
                                            <label class="form-label"><?php echo e($attr->name); ?></label>
                                            <select class="form-select form-select-sm" name="product_attributes[<?php echo e($attr->id); ?>]">
                                                <option value="">Select <?php echo e($attr->name); ?></option>
                                                <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($val->value); ?>" <?php echo e((isset($selectedProductAttrs[$attr->id]) && $selectedProductAttrs[$attr->id] == $val->value) ? 'selected' : ''); ?>>
                                                        <?php echo e($val->value); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <small class="text-muted">Category-specific attributes</small>
                            </div>
                        </div>

                        <!-- Meta Details Card -->
                        <div class="card mt-3">
                            <div class="card-header">
                                <h5><i class="ph-duotone ph-magnifying-glass"></i> SEO Meta</h5>
                            </div>
                            <div class="card-body">
                                <div class="app-form">
                                    <div class="row">
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'meta_title','label' => 'Meta Title','placeholder' => 'SEO optimized title','value' => old('meta_title', $product->meta_title),'error' => $errors->first('meta_title')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'meta_title','label' => 'Meta Title','placeholder' => 'SEO optimized title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('meta_title', $product->meta_title)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('meta_title'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'meta_keywords','label' => 'Meta Keywords','placeholder' => 'keyword1, keyword2, keyword3','value' => old('meta_keywords', $product->meta_keywords),'error' => $errors->first('meta_keywords')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'meta_keywords','label' => 'Meta Keywords','placeholder' => 'keyword1, keyword2, keyword3','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('meta_keywords', $product->meta_keywords)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('meta_keywords'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <?php if (isset($component)) { $__componentOriginalea7b7095850fe8bc9657025b89ccf5a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.textarea','data' => ['rows' => '3','name' => 'meta_description','label' => 'Meta Description','placeholder' => 'SEO meta description (150-160 chars)','value' => old('meta_description', $product->meta_description),'error' => $errors->first('meta_description')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rows' => '3','name' => 'meta_description','label' => 'Meta Description','placeholder' => 'SEO meta description (150-160 chars)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('meta_description', $product->meta_description)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('meta_description'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5)): ?>
<?php $attributes = $__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5; ?>
<?php unset($__attributesOriginalea7b7095850fe8bc9657025b89ccf5a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea7b7095850fe8bc9657025b89ccf5a5)): ?>
<?php $component = $__componentOriginalea7b7095850fe8bc9657025b89ccf5a5; ?>
<?php unset($__componentOriginalea7b7095850fe8bc9657025b89ccf5a5); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-grid gap-2">
                                                <button class="btn btn-primary" type="submit">
                                                    <i class="ph-duotone ph-check-circle"></i> Update Product
                                                </button>
                                                <button class="btn btn-secondary" type="reset">
                                                    <i class="ph-duotone ph-arrow-counter-clockwise"></i> Reset
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles:before'); ?>
    <style>
        .card-header h5 {
            margin-bottom: 0;
        }

        .form-check-input:checked {
            background-color: #667eea;
            border-color: #667eea;
        }

        .badge {
            font-weight: 500;
        }

        #product-attributes-wrapper {
            transition: all 0.3s ease;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts:after'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Slug generation
            const titleInput = document.getElementById('title');
            const slugInput = document.getElementById('slug');

            if (titleInput && slugInput) {
                let slugManuallyEdited = false;

                const slugify = (text) => {
                    return text
                        .toString()
                        .toLowerCase()
                        .trim()
                        .replace(/\s+/g, '-')
                        .replace(/[^\w\-]+/g, '')
                        .replace(/\-\-+/g, '-');
                };

                slugInput.addEventListener('input', () => {
                    slugManuallyEdited = slugInput.value.length > 0;
                });

                titleInput.addEventListener('input', () => {
                    if (!slugManuallyEdited) {
                        slugInput.value = slugify(titleInput.value);
                    }
                });

                slugInput.addEventListener('blur', () => {
                    if (slugInput.value.trim() === '') {
                        slugManuallyEdited = false;
                        slugInput.value = slugify(titleInput.value);
                    }
                });
            }

            // ========================================
            // REACTIVE CATEGORY-BASED ATTRIBUTE FILTERING
            // ========================================
            const categoryInput = document.querySelector('input[name="category_id"]');
            const productAttributesWrapper = document.getElementById('product-attributes-wrapper');
            const productAttributesContainer = document.getElementById('product-attributes-container');

            const fetchAttributesByCategory = async (categoryId) => {
                if (!categoryId) {
                    productAttributesWrapper.style.display = 'none';
                    productAttributesContainer.innerHTML = '';
                    return;
                }

                try {
                    const url =
                        `<?php echo e(route('admin.attributes.by-category')); ?>?category_id=${categoryId}&scope=<?php echo e(\App\Enums\Scope::PRODUCT->value); ?>`;
                    const response = await fetch(url);
                    const data = await response.json();

                    if (data.success) {
                        renderProductAttributes(data.attributes);
                    }
                } catch (error) {
                    console.error('Error fetching attributes:', error);
                    window.toast?.error('Failed to load attributes');
                }
            };

            const renderProductAttributes = (attributes) => {
                // Keep track of currently selected values
                const currentSelections = {};
                productAttributesContainer.querySelectorAll('select').forEach(select => {
                    const attrId = select.name.match(/\[(\d+)\]/)[1];
                    currentSelections[attrId] = select.value;
                });

                productAttributesContainer.innerHTML = '';

                if (attributes.length === 0) {
                    productAttributesWrapper.style.display = 'none';
                    return;
                }

                productAttributesWrapper.style.display = 'block';

                attributes.forEach(attr => {
                    let optionsHtml = `<option value="">Select ${attr.name}</option>`;
                    attr.values.forEach(val => {
                        const selected = currentSelections[attr.id] === val.value ? 'selected' : '';
                        optionsHtml += `<option value="${val.value}" ${selected}>${val.value}</option>`;
                    });

                    const attrHtml = `
                        <div class="mb-3 attribute-item" data-id="${attr.id}">
                            <label class="form-label">${attr.name}</label>
                            <select class="form-select form-select-sm" name="product_attributes[${attr.id}]">
                                ${optionsHtml}
                            </select>
                        </div>
                    `;
                    productAttributesContainer.insertAdjacentHTML('beforeend', attrHtml);
                });
            };

            // Listen to category change from hierarchical select
            if (categoryInput) {
                categoryInput.addEventListener('change', function() {
                    const categoryId = this.value;
                    fetchAttributesByCategory(categoryId);
                });

                // Trigger on page load if category already selected
                const initialCategoryId = categoryInput.value;
                if (initialCategoryId) {
                    fetchAttributesByCategory(initialCategoryId);
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>