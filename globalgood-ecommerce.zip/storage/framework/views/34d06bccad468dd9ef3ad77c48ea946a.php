<nav>
    <div class="app-logo">
        <a class="logo d-inline-block" href="<?php echo e(route('vendor.dashboard')); ?>">
            <img src="<?php echo e(asset('admins/images/logo/1.png')); ?>" alt="#">
        </a>

        <span class="bg-light-primary toggle-semi-nav d-flex-center">
            <i class="ti ti-chevron-right"></i>
        </span>
    </div>
    <div class="app-nav" id="app-simple-bar">
        <ul class="main-nav p-0 mt-2">
            <li class="no-sub">
                <a href="<?php echo e(route('vendor.dashboard')); ?>"
                    class="<?php echo e(request()->routeIs('vendor.dashboard') ? 'active' : ''); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#home"></use>
                    </svg>
                    Dashboard
                </a>
            </li>

            <li class="no-sub">
                <a href="<?php echo e(route('vendor.products.index')); ?>"
                    class="<?php echo e(request()->routeIs('vendor.products.*') ? 'active' : ''); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#product"></use>
                    </svg>
                    Products
                </a>
            </li>
            
            <li class="menu-title"><span>Management</span></li>
            
            
            <li>
                <a aria-expanded="<?php echo e(request()->routeIs('vendor.documents.*') ? 'true' : 'false'); ?>" data-bs-toggle="collapse" href="#documents-menu">
                     <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#document"></use>
                    </svg>
                    Documents
                </a>
                <ul class="collapse <?php echo e(request()->routeIs('vendor.documents.*') ? 'show' : ''); ?>" id="documents-menu">
                    <li><a href="#" onclick="event.preventDefault();">Upload Documents</a></li>
                </ul>
            </li>

            <!-- <li class="menu-title"><span>Account</span></li>

            <li class="no-sub">
                <form action="<?php echo e(route('vendor.logout')); ?>" method="POST" id="logout-form">
                    <?php echo csrf_field(); ?>
                    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                         <svg stroke="currentColor" stroke-width="1.5">
                            <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#sign-out"></use>
                        </svg>
                        Logout
                    </a>
                </form>
            </li> -->
        </ul>
    </div>

    <div class="menu-navs">
        <span class="menu-previous"><i class="ti ti-chevron-left"></i></span>
        <span class="menu-next"><i class="ti ti-chevron-right"></i></span>
    </div>

</nav>
<?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/vendor/layouts/sidebar.blade.php ENDPATH**/ ?>