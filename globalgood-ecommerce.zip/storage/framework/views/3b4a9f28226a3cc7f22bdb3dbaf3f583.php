

<?php $__env->startPush('styles:after'); ?>
<style>
    .discount-card { background: #fff; border-radius: 12px; border: 1px solid #ebebeb; margin-bottom: 20px; }
    .discount-card-header { padding: 16px 20px; border-bottom: 1px solid #f1f2f3; }
    .discount-card-body { padding: 20px; }
    .btn-shopify { background: #303030; color: #fff; font-weight: 600; padding: 8px 16px; border-radius: 8px; border: none; }
    .btn-shopify:hover { background: #1a1a1a; color: #fff; }
    .form-label { font-size: 13px; font-weight: 600; color: #1a1c1d; margin-bottom: 8px; }
    .summary-card { background: #fff; border-radius: 12px; border: 1px solid #ebebeb; padding: 20px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4" style="max-width: 1100px;">
    <div class="d-flex align-items-center mb-4">
        <a href="<?php echo e(route('admin.discounts.index')); ?>" class="text-dark me-2"><i class="ph ph-arrow-left"></i></a>
        <h4 class="mb-0 f-w-700"><?php echo e($discount->code ?? $discount->title); ?></h4>
    </div>

    <form action="<?php echo e(route('admin.discounts.update', $discount->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="discount-card">
                    <div class="discount-card-header border-0 pb-0"><h6 class="mb-0 f-w-600">Buy X get Y</h6></div>
                    <div class="discount-card-body">
                        <label class="form-label">Method</label>
                        <div class="btn-group w-100 mb-4">
                            <input type="radio" class="btn-check" name="method" id="method_code" value="code" <?php echo e($discount->method == 'code' ? 'checked' : ''); ?>>
                            <label class="btn btn-outline-secondary" for="method_code">Discount code</label>
                            <input type="radio" class="btn-check" name="method" id="method_automatic" value="automatic" <?php echo e($discount->method == 'automatic' ? 'checked' : ''); ?>>
                            <label class="btn btn-outline-secondary" for="method_automatic">Automatic discount</label>
                        </div>
                        <div id="codeSection" class="<?php echo e($discount->method == 'automatic' ? 'd-none' : ''); ?>">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="form-label mb-0">Discount code</label>
                                <a href="javascript:void(0)" id="generateCode" class="text-primary f-s-13 text-decoration-none">Generate random code</a>
                            </div>
                            <input type="text" name="code" id="discountCode" class="form-control" value="<?php echo e($discount->code); ?>">
                        </div>
                        <div id="titleSection" class="<?php echo e($discount->method == 'code' ? 'd-none' : ''); ?>">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" id="discountTitle" class="form-control" value="<?php echo e($discount->title); ?>">
                        </div>
                    </div>
                </div>

                <div class="discount-card">
                    <div class="discount-card-header border-0 pb-0"><h6 class="mb-0 f-w-600">Customer buys</h6></div>
                    <div class="discount-card-body">
                        <div class="form-check mb-2"><input class="form-check-input" type="radio" name="buy_type" id="buy_qty" value="quantity" <?php echo e($discount->buy_type == 'quantity' ? 'checked' : ''); ?>><label class="form-check-label" for="buy_qty">Minimum quantity of items</label></div>
                        <div class="form-check mb-3"><input class="form-check-input" type="radio" name="buy_type" id="buy_amount" value="amount" <?php echo e($discount->buy_type == 'amount' ? 'checked' : ''); ?>><label class="form-check-label" for="buy_amount">Minimum purchase amount (₹)</label></div>
                        <div class="row mb-3">
                            <div class="col-md-4"><label class="form-label">Quantity/Amount</label><input type="number" name="buy_value" class="form-control" value="<?php echo e($discount->buy_value); ?>"></div>
                            <div class="col-md-8">
                                <label class="form-label">Any items from</label>
                                <select name="buy_items_type" class="form-select items-type-select" data-target="#buySelectedItems">
                                    <option value="products">Specific products</option>
                                    <option value="collections">Specific collections</option>
                                </select>
                            </div>
                        </div>
                        <div id="buySelectionArea">
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="ph ph-magnifying-glass"></i></span>
                                <input type="text" class="form-control border-start-0" placeholder="Search items...">
                                <button class="btn btn-outline-secondary browse-items-btn" type="button" 
                                    data-target-area="#buySelectedItems" 
                                    data-target-input="buy_items[]"
                                    data-type-input="buy_target_types[]">Browse</button>
                            </div>
                            <div id="buySelectedItems" class="mt-3">
                                <?php $__currentLoopData = $discount->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->collection_id): ?>
                                        <?php $collection = $collections->find($item->collection_id); ?>
                                        <?php if($collection): ?>
                                            <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-light rounded" id="selected-buy-collection-<?php echo e($collection->id); ?>">
                                                <div class="d-flex align-items-center">
                                                    <i class="ph ph-folders me-2"></i>
                                                    <span class="f-s-13"><?php echo e($collection->title); ?></span>
                                                    <input type="hidden" name="buy_items[]" value="<?php echo e($collection->id); ?>">
                                                    <input type="hidden" name="buy_target_types[]" value="collection">
                                                </div>
                                                <button type="button" class="btn btn-link link-danger p-0 ms-2" onclick="$(this).closest('.rounded').remove()"><i class="ph ph-x"></i></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($item->product_id): ?>
                                        <?php
                                            $product = $products->find($item->product_id);
                                            $selectedVariants = $item->variant_ids ?? [];
                                            $isFull = empty($selectedVariants);
                                            $totalVariants = $product->variants->count();
                                            $subtitle = $isFull ? 'All variants selected' : (count($selectedVariants) . ' of ' . $totalVariants . ' variants selected');
                                            $image = $product->images->first()->path ?? null;
                                            $imgSrc = $image ? asset('storage/'.$image) : asset('admins/svg/_sprite.svg#shop');
                                        ?>
                                        <?php if($product): ?>
                                            <div class="d-flex align-items-center justify-content-between p-3 mb-2 border rounded bg-white shadow-sm">
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo e($imgSrc); ?>" class="rounded me-3" style="width: 40px; height: 40px; object-fit: cover; border: 1px solid #eee;">
                                                    <div>
                                                        <div class="f-s-14 f-w-600 text-dark"><?php echo e($product->title); ?></div>
                                                        <div class="f-s-13 text-muted"><?php echo e($subtitle); ?></div>
                                                    </div>
                                                    <div class="d-none">
                                                        <?php if($isFull): ?>
                                                            <input type="hidden" name="buy_items[]" value="<?php echo e($product->id); ?>">
                                                            <input type="hidden" name="buy_target_types[]" value="product">
                                                        <?php else: ?>
                                                            <?php $__currentLoopData = $selectedVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <input type="hidden" name="buy_items[]" value="<?php echo e($vid); ?>">
                                                                <input type="hidden" name="buy_target_types[]" value="variant">
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <button type="button" class="btn btn-link link-secondary p-0" onclick="$(this).closest('.border').remove()"><i class="ph ph-x"></i></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Customer Gets -->
                <div class="discount-card">
                    <div class="discount-card-header border-0 pb-0"><h6 class="mb-0 f-w-600">Customer gets</h6></div>
                    <div class="discount-card-body">
                        <div class="row mb-3">
                            <div class="col-md-4"><label class="form-label">Quantity</label><input type="number" name="get_quantity" class="form-control" value="<?php echo e($discount->get_quantity); ?>"></div>
                            <div class="col-md-8">
                                <label class="form-label">Any items from</label>
                                <select name="get_items_type" class="form-select items-type-select" data-target="#getSelectedItems">
                                    <option value="products">Specific products</option>
                                    <option value="collections">Specific collections</option>
                                </select>
                            </div>
                        </div>
                        <div id="getSelectionArea" class="mb-4">
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="ph ph-magnifying-glass"></i></span>
                                <input type="text" class="form-control border-start-0" placeholder="Search items...">
                                <button class="btn btn-outline-secondary browse-items-btn" type="button" 
                                    data-target-area="#getSelectedItems" 
                                    data-target-input="get_items[]"
                                    data-type-input="get_target_types[]">Browse</button>
                            </div>
                            <div id="getSelectedItems" class="mt-3">
                                <?php $__currentLoopData = $discount->rewardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->collection_id): ?>
                                        <?php $collection = $collections->find($item->collection_id); ?>
                                        <?php if($collection): ?>
                                            <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-light rounded" id="selected-get-collection-<?php echo e($collection->id); ?>">
                                                <div class="d-flex align-items-center">
                                                    <i class="ph ph-folders me-2"></i>
                                                    <span class="f-s-13"><?php echo e($collection->title); ?></span>
                                                    <input type="hidden" name="get_items[]" value="<?php echo e($collection->id); ?>">
                                                    <input type="hidden" name="get_target_types[]" value="collection">
                                                </div>
                                                <button type="button" class="btn btn-link link-danger p-0 ms-2" onclick="$(this).closest('.rounded').remove()"><i class="ph ph-x"></i></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($item->product_id): ?>
                                        <?php
                                            $product = $products->find($item->product_id);
                                            $selectedVariants = $item->variant_ids ?? [];
                                            $isFull = empty($selectedVariants);
                                            $totalVariants = $product->variants->count();
                                            $subtitle = $isFull ? 'All variants selected' : (count($selectedVariants) . ' of ' . $totalVariants . ' variants selected');
                                            $image = $product->images->first()->path ?? null;
                                            $imgSrc = $image ? asset('storage/'.$image) : asset('admins/svg/_sprite.svg#shop');
                                        ?>
                                        <?php if($product): ?>
                                            <div class="d-flex align-items-center justify-content-between p-3 mb-2 border rounded bg-white shadow-sm">
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo e($imgSrc); ?>" class="rounded me-3" style="width: 40px; height: 40px; object-fit: cover; border: 1px solid #eee;">
                                                    <div>
                                                        <div class="f-s-14 f-w-600 text-dark"><?php echo e($product->title); ?></div>
                                                        <div class="f-s-13 text-muted"><?php echo e($subtitle); ?></div>
                                                    </div>
                                                    <div class="d-none">
                                                        <?php if($isFull): ?>
                                                            <input type="hidden" name="get_items[]" value="<?php echo e($product->id); ?>">
                                                            <input type="hidden" name="get_target_types[]" value="product">
                                                        <?php else: ?>
                                                            <?php $__currentLoopData = $selectedVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <input type="hidden" name="get_items[]" value="<?php echo e($vid); ?>">
                                                                <input type="hidden" name="get_target_types[]" value="variant">
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <button type="button" class="btn btn-link link-secondary p-0" onclick="$(this).closest('.border').remove()"><i class="ph ph-x"></i></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Active Dates -->
                <div class="discount-card">
                    <div class="discount-card-header border-0 pb-0"><h6 class="mb-0 f-w-600">Active dates</h6></div>
                    <div class="discount-card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3"><label class="form-label">Start date</label><input type="date" name="starts_at_date" class="form-control" value="<?php echo e($discount->starts_at->format('Y-m-d')); ?>"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Start time (IST)</label><input type="time" name="starts_at_time" class="form-control" value="<?php echo e($discount->starts_at->format('H:i')); ?>"></div>
                        </div>
                    </div>
                </div>
                
                <!-- Eligibility Fix -->
                <div class="discount-card">
                    <div class="discount-card-header border-0 pb-0"><h6 class="mb-0 f-w-600">Eligibility</h6></div>
                    <div class="discount-card-body">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="customer_selection" id="elig_all" value="all" <?php echo e($discount->customer_selection == 'all' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="elig_all">All customers</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="customer_selection" id="elig_specific" value="specific" <?php echo e($discount->customer_selection == 'specific' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="elig_specific">Specific customers</label>
                        </div>
                        <div id="customerSelectionArea" class="ms-4 mt-3 <?php echo e($discount->customer_selection != 'specific' ? 'd-none' : ''); ?>">
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="ph ph-magnifying-glass"></i></span>
                                <input type="text" class="form-control border-start-0" placeholder="Search customers" id="customerSearchTrigger">
                                <button class="btn btn-outline-secondary" type="button" id="browseCustomersBtn" data-target-input="customer_ids[]">Browse</button>
                            </div>
                            <div id="selectedCustomers" class="mt-3">
                                <?php $__currentLoopData = $discount->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-light rounded" id="selected-customer-<?php echo e($customer->id); ?>">
                                        <div class="d-flex align-items-center">
                                            <i class="ph ph-user me-2"></i>
                                            <span class="f-s-13"><?php echo e($customer->full_name); ?></span>
                                            <input type="hidden" name="customer_ids[]" value="<?php echo e($customer->id); ?>">
                                        </div>
                                        <button type="button" class="btn btn-link link-danger p-0 ms-2" onclick="$(this).closest('.bg-light').remove()">
                                            <i class="ph ph-x"></i>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="summary-card">
                    <h6 class="f-w-600">Summary</h6>
                    <hr>
                    <button type="submit" class="btn btn-shopify w-100 mb-3">Save changes</button>
                    <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-light border w-100">Cancel</a>
                </div>
            </div>
        </div>
    </form>
</div>

<?php echo $__env->make('admin.discounts._modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts:after'); ?>
<script>
    function generateRandomCode(length = 8) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    $(document).ready(function() {
        $('#generateCode').on('click', function() {
            $('#discountCode').val(generateRandomCode());
        });

        $('.items-type-select').on('change', function() {
            const targetArea = $(this).data('target');
            $(targetArea).empty();
        });

        $('input[name="method"]').on('change', function() {
            const isCode = $(this).val() === 'code';
            $('#codeSection').toggleClass('d-none', !isCode);
            $('#titleSection').toggleClass('d-none', isCode);
        });

        $('input[name="customer_selection"]').on('change', function() {
            $('#customerSelectionArea').toggleClass('d-none', $(this).val() !== 'specific');
        });

        initializeDiscountModals('products');
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/admin/discounts/edit-buy-x-get-y.blade.php ENDPATH**/ ?>