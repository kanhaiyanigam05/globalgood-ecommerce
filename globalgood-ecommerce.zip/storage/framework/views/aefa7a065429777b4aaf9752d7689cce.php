<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id' => null,
    'label' => null,
    'error' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id' => null,
    'label' => null,
    'error' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $groupClass = 'form-check';
    $inputClass = 'form-check-input';
    $inputClass .= $error ? ' is-invalid' : '';
?>

<div class="<?php echo e($groupClass); ?>">
    <input type="checkbox" id="<?php echo e($id); ?>" <?php if($required): echo 'required'; endif; ?> <?php echo $attributes->merge(['class' => $inputClass]); ?>>

    <label class="form-check-label" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

        <?php if($required): ?>
            <span class="text-danger">*</span>
        <?php endif; ?>
    </label>

    <?php if($error): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($error); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/components/forms/checkbox.blade.php ENDPATH**/ ?>