<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Profile Overview -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <?php if($vendor->profile && $vendor->profile->logo): ?>
                                <img src="<?php echo e(asset('storage/' . $vendor->profile->logo)); ?>" alt="Logo" class="rounded-circle" width="60" height="60">
                            <?php else: ?>
                                <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                    <i class="ph ph-storefront f-s-30"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="mb-1"><?php echo e($vendor->profile->store_name ?? 'Store Setup Pending'); ?></h5>
                            <p class="text-muted mb-0"><?php echo e($vendor->legal_name); ?></p>
                            <span class="badge bg-<?php echo e($vendor->status === 'verified' ? 'success' : ($vendor->status === 'pending' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($vendor->status)); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Verification Status -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Compliance & Verification</h5>
                </div>
                <div class="card-body">
                    <?php if($vendor->kyc_status !== 'verified'): ?>
                        <div class="alert alert-warning">
                            <i class="ph ph-warning-circle me-1"></i>
                            Your account requires verification before you can start selling. Please upload the required documents.
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive mb-4">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Document Type</th>
                                    <th>Status</th>
                                    <th>Uploaded At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $uploadedTypes = $vendor->documents->pluck('document_type')->toArray();
                                    $requiredTypes = ['GST', 'PAN', 'ID'];
                                    $allUploaded = count(array_intersect($requiredTypes, $uploadedTypes)) === count($requiredTypes);
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $vendor->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($doc->document_type); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($doc->status === 'verified' ? 'success' : ($doc->status === 'pending' ? 'warning' : 'danger')); ?>">
                                                <?php echo e(ucfirst($doc->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($doc->created_at->format('d M Y')); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-light-primary" onclick="toggleEditDoc('<?php echo e($doc->document_type); ?>')">
                                                <i class="ph ph-pencil"></i> Update
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No documents uploaded yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="upload-form-container" style="<?php echo e($allUploaded ? 'display:none;' : ''); ?>">
                        <h6 class="mb-3">Upload New Document</h6>
                        <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['method' => 'POST','action' => ''.e(route('vendor.documents.upload')).'','enctype' => 'multipart/form-data']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['method' => 'POST','action' => ''.e(route('vendor.documents.upload')).'','enctype' => 'multipart/form-data']); ?>
                            <div class="row align-items-end">
                                <div class="col-md-4">
                                    <?php if (isset($component)) { $__componentOriginal7041cc63efd62f0450fe4bb37aadf484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7041cc63efd62f0450fe4bb37aadf484 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.select','data' => ['id' => 'document_type','name' => 'document_type','label' => 'Document Type','options' => ['GST' => 'GST Certificate', 'PAN' => 'PAN Card', 'ID' => 'Government ID'],'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'document_type','name' => 'document_type','label' => 'Document Type','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['GST' => 'GST Certificate', 'PAN' => 'PAN Card', 'ID' => 'Government ID']),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7041cc63efd62f0450fe4bb37aadf484)): ?>
<?php $attributes = $__attributesOriginal7041cc63efd62f0450fe4bb37aadf484; ?>
<?php unset($__attributesOriginal7041cc63efd62f0450fe4bb37aadf484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7041cc63efd62f0450fe4bb37aadf484)): ?>
<?php $component = $__componentOriginal7041cc63efd62f0450fe4bb37aadf484; ?>
<?php unset($__componentOriginal7041cc63efd62f0450fe4bb37aadf484); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-5">
                                    <?php if (isset($component)) { $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.file','data' => ['id' => 'document_file','name' => 'document_file','label' => 'Select File','required' => true,'error' => $errors->first('document_file')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'document_file','name' => 'document_file','label' => 'Select File','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('document_file'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $attributes = $__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__attributesOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c)): ?>
<?php $component = $__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c; ?>
<?php unset($__componentOriginal3e903a5b1d9ce9261a6e2c147356ad2c); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary w-100">Upload</button>
                                </div>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Bank Accounts -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Bank Account Details</h5>
                    <?php if($vendor->bankAccounts->isNotEmpty()): ?>
                        <button type="button" class="btn btn-sm btn-outline-primary" id="edit-bank-btn" onclick="toggleBankEdit()">
                            <i class="ph ph-pencil"></i> Edit Details
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php
                        $bankAccount = $vendor->bankAccounts->where('is_primary', true)->first();
                    ?>

                    <?php if($bankAccount): ?>
                        <div id="bank-display-section">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="text-muted small">Bank Name</label>
                                    <p class="mb-0 fw-bold"><?php echo e($bankAccount->bank_name); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="text-muted small">Account Holder Name</label>
                                    <p class="mb-0 fw-bold"><?php echo e($bankAccount->account_holder_name); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="text-muted small">Account Number</label>
                                    <p class="mb-0 fw-bold"><?php echo e($bankAccount->account_number); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="text-muted small">IFSC Code</label>
                                    <p class="mb-0 fw-bold"><?php echo e($bankAccount->ifsc_code); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="text-muted small">Verification Status</label>
                                    <br>
                                    <span class="badge bg-<?php echo e($bankAccount->status === 'verified' ? 'success' : ($bankAccount->status === 'pending' ? 'warning' : 'danger')); ?>">
                                        <?php echo e(ucfirst($bankAccount->status ?? 'pending')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div id="bank-form-section" style="<?php echo e($bankAccount ? 'display:none;' : ''); ?>">
                        <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['method' => 'POST','action' => ''.e(route('vendor.bank_details.update')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['method' => 'POST','action' => ''.e(route('vendor.bank_details.update')).'']); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'bank_name','name' => 'bank_name','label' => 'Bank Name','value' => $bankAccount->bank_name ?? '','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'bank_name','name' => 'bank_name','label' => 'Bank Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bankAccount->bank_name ?? ''),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'account_holder_name','name' => 'account_holder_name','label' => 'Account Holder Name','value' => $bankAccount->account_holder_name ?? '','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'account_holder_name','name' => 'account_holder_name','label' => 'Account Holder Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bankAccount->account_holder_name ?? ''),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'account_number','name' => 'account_number','label' => 'Account Number','value' => $bankAccount->account_number ?? '','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'account_number','name' => 'account_number','label' => 'Account Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bankAccount->account_number ?? ''),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['id' => 'ifsc_code','name' => 'ifsc_code','label' => 'IFSC Code','value' => $bankAccount->ifsc_code ?? '','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'ifsc_code','name' => 'ifsc_code','label' => 'IFSC Code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bankAccount->ifsc_code ?? ''),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                </div>
                                <div class="col-12 mt-3">
                                    <button type="submit" class="btn btn-primary">Save Bank Details</button>
                                    <?php if($bankAccount): ?>
                                        <button type="button" class="btn btn-light ms-2" onclick="toggleBankEdit()">Cancel</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleEditDoc(type) {
    const container = document.getElementById('upload-form-container');
    container.style.display = 'block';
    const select = document.getElementById('document_type');
    select.value = type;
    // Highlight the form or scroll to it
    container.scrollIntoView({ behavior: 'smooth' });
}

function toggleBankEdit() {
    const display = document.getElementById('bank-display-section');
    const form = document.getElementById('bank-form-section');
    const btn = document.getElementById('edit-bank-btn');

    if (form.style.display === 'none') {
        form.style.display = 'block';
        if (display) display.style.display = 'none';
        btn.innerHTML = '<i class="ph ph-x"></i> Cancel Edit';
    } else {
        form.style.display = 'none';
        if (display) display.style.display = 'block';
        btn.innerHTML = '<i class="ph ph-pencil"></i> Edit Details';
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\globalgood-ecommerce\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>