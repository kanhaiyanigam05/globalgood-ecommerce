<?php $__env->startPush('styles:after'); ?>
    <style>
        :root {
            --header-height: 65px;
        }

        /* Essential Sidebar Layout */
        .variant-sidebar {
            background: #ffffff;
            border-right: 1px solid #e5e8eb;
            height: calc(100vh - var(--header-height));
            position: sticky;
            top: var(--header-height);
            overflow-y: auto;
            z-index: 10;
        }

        .variant-item {
            padding: 12px 16px;
            margin: 4px 8px;
            border-radius: 8px;
            transition: all 0.2s;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: inherit;
            border: 1px solid transparent;
        }

        .variant-item:hover {
            background-color: #f8fafc;
            border-color: #e9ecef;
        }

        .variant-item.active {
            background-color: #e7f3ff;
            border-color: var(--primary);
            border-left-width: 4px;
        }

        .variant-item img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
        }

        .variant-info-top {
            padding: 16px;
            border-bottom: 1px solid #e5e8eb;
            background: #fafbfc;
        }

        .search-box {
            padding: 12px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .loading-overlay.active {
            display: flex;
        }

        @media (max-width: 768px) {
            .variant-sidebar {
                position: relative;
                height: auto;
                border-right: none;
                border-bottom: 1px solid #e5e8eb;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <!-- Breadcrumb start -->
        <div class="row m-1">
            <div class="col-12">
                <h4 class="main-title">Edit Variant</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li>
                        <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.products.index')); ?>">
                            <span><i class="ph-duotone ph-package f-s-16"></i> Products</span>
                        </a>
                    </li>
                    <li>
                        <a class="f-s-14 f-w-500" href="<?php echo e(route('admin.products.edit', Crypt::encryptString($product->id))); ?>">
                            <span><i class="ph-duotone ph-folder f-s-16"></i> <?php echo e($product->title); ?></span>
                        </a>
                    </li>
                    <li class="active">
                        <a class="f-s-14 f-w-500" href="javascript:void(0)"><?php echo e($variant->attributes->map(fn($a) => $a->pivot->value)->implode(' / ') ?: 'Default Variant'); ?></a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row g-0">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 variant-sidebar">
                <div class="variant-info-top">
                    <div class="d-flex align-items-center gap-2">
                        <img src="<?php echo e($product->firstImage() ? $product->firstImage()->file_url : 'https://placehold.co/40x40'); ?>" class="rounded" width="100">
                        <div class="flex-grow-1 min-w-0">
                            <h6 class="mb-0 text-truncate f-s-13 text-wrap"><?php echo e($product->title); ?></h6>
                            <span class="badge <?php echo e($product->status ? 'text-bg-success' : 'text-bg-danger'); ?> f-s-10">
                                <?php echo e($product->status ? 'Active' : 'Inactive'); ?>

                            </span>
                        </div>
                    </div>
                </div>

                <div class="search-box">
                    <div class="input-group input-group-sm mb-2">
                        <span class="input-group-text bg-white border-end-0"><i class="ph ph-magnifying-glass"></i></span>
                        <input type="text" class="form-control border-start-0" id="variantSearch" placeholder="Search variants...">
                    </div>
                    
                    <div class="dropdown dropdown-sm w-100">
                        <button class="btn btn-light btn-sm dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
                            <i class="ph ph-funnel me-1"></i> Filter
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">All Variants</a></li>
                        </ul>
                    </div>
                </div>

                <div class="variant-list" id="variantList">
                    <?php $encryptedProductId = \Crypt::encryptString($product->id); ?>
                    <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $vTitle = $v->attributes->map(fn($a) => $a->pivot->value)->implode(' / ') ?: 'Default Variant';
                            $vEncryptedId = \Crypt::encryptString($v->id);
                        ?>
                        <a href="<?php echo e(route('admin.products.variants.edit', [$encryptedProductId, $vEncryptedId])); ?>"
                            class="variant-item <?php echo e($v->id == $variant->id ? 'active' : ''); ?>"
                            data-title="<?php echo e(strtolower($vTitle)); ?>">
                            <img src="<?php echo e($product->firstImage() ? $product->firstImage()->file_url : 'https://placehold.co/40x40'); ?>">
                            <div class="text-truncate flex-grow-1">
                                <p class="mb-0 f-w-500 f-s-12 text-truncate text-dark"><?php echo e($vTitle); ?></p>
                                <p class="mb-0 text-muted f-s-11"><?php echo e($v->quantity); ?> available</p>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Main Area -->
            <div class="col-md-9 col-lg-10 p-4 bg-light">
                <div class="mx-auto" style="max-width: 900px;">
                    <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['varient' => 'reactive','action' => route('admin.products.variants.update', [$encryptedProductId, \Crypt::encryptString($variant->id)]),'method' => 'PUT']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['varient' => 'reactive','action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.variants.update', [$encryptedProductId, \Crypt::encryptString($variant->id)])),'method' => 'PUT']); ?>
                        <?php $currentVTitle = $variant->attributes->map(fn($a) => $a->pivot->value)->implode(' / ') ?: 'Default Variant'; ?>
                        
                        <!-- Variant Info -->
                        <div class="card mb-4 shadow-sm border-0">
                            <div class="card-body">
                                <h5 class="card-title mb-4">
                                    <i class="ph ph-tag text-primary me-2"></i>
                                    <?php echo e($currentVTitle); ?>

                                </h5>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger border-0 shadow-sm d-flex align-items-center mb-4">
                                        <i class="ph ph-warning-circle f-s-20 me-2"></i>
                                        <div>
                                            <ul class="mb-0">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="alert alert-info border-0 shadow-sm d-flex align-items-center mb-4">
                                    <i class="ph ph-info f-s-20 me-2"></i>
                                    <span>These attributes define what makes this variant unique from other variants of this product.</span>
                                </div>

                                <?php $variantAttributesMap = $variant->attributes->pluck('pivot.value', 'id')->toArray(); ?>
                                <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3">
                                            <input type="hidden" name="attributes[<?php echo e($index); ?>][attribute_id]" value="<?php echo e($attribute->id); ?>">
                                            <?php if (isset($component)) { $__componentOriginal7041cc63efd62f0450fe4bb37aadf484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7041cc63efd62f0450fe4bb37aadf484 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.select','data' => ['name' => 'attributes['.e($index).'][value]','label' => $attribute->name,'options' => $attribute->values->pluck('value', 'value')->toArray(),'value' => $variantAttributesMap[$attribute->id] ?? '','placeholder' => 'Select '.e($attribute->name).'','error' => $errors->first('attributes.'.$index.'.value'),'disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'attributes['.e($index).'][value]','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attribute->name),'options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attribute->values->pluck('value', 'value')->toArray()),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variantAttributesMap[$attribute->id] ?? ''),'placeholder' => 'Select '.e($attribute->name).'','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('attributes.'.$index.'.value')),'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7041cc63efd62f0450fe4bb37aadf484)): ?>
<?php $attributes = $__attributesOriginal7041cc63efd62f0450fe4bb37aadf484; ?>
<?php unset($__attributesOriginal7041cc63efd62f0450fe4bb37aadf484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7041cc63efd62f0450fe4bb37aadf484)): ?>
<?php $component = $__componentOriginal7041cc63efd62f0450fe4bb37aadf484; ?>
<?php unset($__componentOriginal7041cc63efd62f0450fe4bb37aadf484); ?>
<?php endif; ?>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Pricing Section -->
                        <div class="card mb-4 shadow-sm <?php if($errors->has('price') || $errors->has('compare_at_price')): ?> border border-danger <?php else: ?> border-0 <?php endif; ?>">
                            <div class="card-header bg-white py-3 border-0">
                                <h6 class="mb-0 f-w-600"><i class="ph-duotone ph-currency-circle-dollar me-2"></i>Pricing</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'number','name' => 'price','label' => 'Price','step' => '0.01','value' => old('price', $variant->price_formatted),'error' => $errors->first('price'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'price','label' => 'Price','step' => '0.01','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('price', $variant->price_formatted)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('price')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        <small class="text-muted"><i class="ph ph-info me-1"></i>Customer-facing price</small>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'number','name' => 'compare_at_price','label' => 'Compare-At Price','step' => '0.01','value' => old('compare_at_price', $variant->compare_at_price_formatted),'error' => $errors->first('compare_at_price')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'compare_at_price','label' => 'Compare-At Price','step' => '0.01','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('compare_at_price', $variant->compare_at_price_formatted)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('compare_at_price'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        <small class="text-muted"><i class="ph ph-tag me-1"></i>Show savings to customers</small>
                                    </div>
                                </div>

                                <?php if(old('compare_at_price', $variant->compare_at_price_formatted)): ?>
                                    <?php
                                        $price = old('price', $variant->price_formatted);
                                        $comparePrice = old('compare_at_price', $variant->compare_at_price_formatted);
                                        $savings = $comparePrice > $price ? (($comparePrice - $price) / $comparePrice * 100) : 0;
                                    ?>
                                    <?php if($savings > 0): ?>
                                        <div class="alert alert-success mt-3 mb-0 border-0 shadow-sm">
                                            <i class="ph ph-check-circle me-2"></i>
                                            <strong>Customers save <?php echo e(number_format($savings, 0)); ?>%</strong> ($<?php echo e(number_format($comparePrice - $price, 2)); ?>)
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Inventory Section -->
                        <div class="card mb-4 shadow-sm <?php if($errors->has('quantity') || $errors->has('sku')): ?> border border-danger <?php else: ?> border-0 <?php endif; ?>">
                            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-0">
                                <h6 class="mb-0 f-w-600"><i class="ph-duotone ph-warehouse me-2"></i>Inventory</h6>
                                
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table mb-0 align-middle">
                                        <thead class="bg-light-subtle">
                                            <tr>
                                                <th class="ps-4 border-0">Location</th>
                                                <th class="border-0">Available</th>
                                                <th class="border-0 text-end pe-4">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="ps-4">
                                                    <strong>Global Good Store</strong><br>
                                                    <small class="text-muted">Primary Location</small>
                                                </td>
                                                <td>
                                                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['label' => 'Quantity','type' => 'number','name' => 'quantity','value' => old('quantity', $variant->quantity),'error' => $errors->first('quantity'),'required' => true,'style' => 'width: 120px;','min' => '0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Quantity','type' => 'number','name' => 'quantity','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('quantity', $variant->quantity)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('quantity')),'required' => true,'style' => 'width: 120px;','min' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                                </td>
                                                <td class="text-end pe-4">
                                                    <?php $qty = old('quantity', $variant->quantity); ?>
                                                    <?php if($qty <= 0): ?>
                                                        <span class="badge text-bg-danger">Out of Stock</span>
                                                    <?php elseif($qty < 10): ?>
                                                        <span class="badge text-bg-warning text-dark">Low Stock</span>
                                                    <?php else: ?>
                                                        <span class="badge text-bg-success">In Stock</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="p-4 border-top bg-light-subtle">
                                    <div class="row">
                                        <div class="col-md-6 mb-3 mb-md-0">
                                            <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'sku','label' => 'SKU (Stock Keeping Unit)','value' => old('sku', $variant->sku),'error' => $errors->first('sku'),'placeholder' => 'e.g. WH-01-L']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sku','label' => 'SKU (Stock Keeping Unit)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('sku', $variant->sku)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('sku')),'placeholder' => 'e.g. WH-01-L']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Shipping Section -->
                        

                        <!-- Actions -->
                        <div class="d-flex justify-content-between align-items-center mb-5">
                            <a href="<?php echo e(route('admin.products.edit', $encryptedProductId)); ?>" class="btn btn-outline-secondary">
                                <i class="ph ph-arrow-left me-1"></i> Back to Product
                            </a>
                            <button type="submit" class="btn btn-primary px-5 py-2">
                                <i class="ph ph-check-circle me-1"></i> Save Variant
                            </button>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="text-center">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="mt-3 text-muted">Saving changes...</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts:after'); ?>
    <script>
        $(document).ready(function() {
            // Variant Search Filtering
            $('#variantSearch').on('keyup', function() {
                var value = $(this).val().toLowerCase();
                $('#variantList .variant-item').each(function() {
                    $(this).toggle($(this).data('title').indexOf(value) > -1);
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/admin/variants/edit.blade.php ENDPATH**/ ?>