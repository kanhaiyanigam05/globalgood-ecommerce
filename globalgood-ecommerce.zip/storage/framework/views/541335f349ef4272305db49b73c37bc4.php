<!-- Menu Navigation starts -->
<nav class="vertical-sidebar">
    <div class="app-logo">
        <a class="logo d-inline-block" href="ecommerce.html">
            <img src="<?php echo e(asset($data->site_logo)); ?>" alt="#">
        </a>

        <span class="bg-light-primary toggle-semi-nav d-flex-center">
            <i class="ti ti-chevron-right"></i>
        </span>
    </div>
    <div class="app-nav" id="app-simple-bar">
        <ul class="main-nav p-0 mt-2">
            <li class="no-sub">
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                    aria-expanded="<?php echo e(request()->routeIs('admin.dashboard') ? 'true' : 'false'); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#home"></use>
                    </svg>
                    dashboard
                </a>
            </li>
            <li class="no-sub">
                <a href="<?php echo e(route('admin.vendors.index')); ?>"
                    aria-expanded="<?php echo e(request()->routeIs('admin.vendors.*') ? 'true' : 'false'); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#vendors"></use>
                    </svg>
                    Vendors
                </a>
            </li>
            <li class="no-sub">
                <a href="<?php echo e(route('admin.orders.index')); ?>"
                    aria-expanded="<?php echo e(request()->routeIs('admin.orders.*') ? 'true' : 'false'); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#orders"></use>
                    </svg>
                    Orders
                </a>
            </li>
            <li>
                <a aria-expanded="false" data-bs-toggle="collapse" href="#shop-menu">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#shop"></use>
                    </svg>
                    Shop
                </a>
                <ul class="collapse" id="shop-menu">
                    <li><a href="<?php echo e(route('admin.collections.index')); ?>">Collections</a></li>
                    <li><a href="<?php echo e(route('admin.categories.index')); ?>">Categories</a></li>
                    <li><a href="<?php echo e(route('admin.variants.all')); ?>">All Variants</a></li>
                    <li><a href="<?php echo e(route('admin.products.index')); ?>">Products</a></li>
                    <li><a href="<?php echo e(route('admin.products.create')); ?>">Add Product</a></li>
                    <li><a href="<?php echo e(route('admin.attributes.index')); ?>">Attributes</a></li>
                </ul>
            </li>
            <li class="no-sub">
                <a href="<?php echo e(route('admin.customers.index')); ?>"
                    aria-expanded="<?php echo e(request()->routeIs('admin.customers.*') ? 'true' : 'false'); ?>">
                    <svg stroke="currentColor" stroke-width="1.5">
                        <use xlink:href="<?php echo e(asset('admins/svg/_sprite.svg')); ?>#customers"></use>
                    </svg>
                    Customers
                </a>
            </li>
            


        </ul>
    </div>

    <div class="menu-navs">
        <span class="menu-previous"><i class="ti ti-chevron-left"></i></span>
        <span class="menu-next"><i class="ti ti-chevron-right"></i></span>
    </div>

</nav>
<!-- Menu Navigation ends -->
<?php /**PATH E:\laragon\www\globalgood-ecommerce\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>